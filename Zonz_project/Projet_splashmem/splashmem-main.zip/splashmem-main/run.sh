#!/bin/bash

./build/src/splashmem ./build/player/libplayer1.so ./build/player/libplayer2.so ../build/player/libplayer3.so ./build/player/libplayer4.so

